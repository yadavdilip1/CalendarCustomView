package com.example.calendarcustomview.ui.main

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
}