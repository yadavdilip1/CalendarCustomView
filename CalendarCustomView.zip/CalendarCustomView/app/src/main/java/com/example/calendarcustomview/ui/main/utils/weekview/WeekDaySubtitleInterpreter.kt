package com.example.calendarcustomview.ui.main.utils.weekview

import java.util.*

interface WeekDaySubtitleInterpreter {
    fun getFormattedWeekDaySubtitle(date: Calendar): String
}
