package com.example.calendarcustomview.ui.main.utils.weekview

import androidx.annotation.ColorInt

interface TextColorPicker {

    @ColorInt
    fun getTextColor(event: WeekViewEvent): Int

}
