package com.example.calendarcustomview.ui.main

import android.content.ClipData
import android.graphics.RectF
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.util.TypedValue
import android.view.*
import android.widget.Toast
import androidx.core.content.res.ResourcesCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.example.calendarcustomview.R
import com.example.calendarcustomview.databinding.MainFragmentBinding
import com.example.calendarcustomview.ui.main.utils.weekview.*
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

class MainFragment : Fragment(), WeekView.EventClickListener, MonthLoader.MonthChangeListener, WeekView.EventLongPressListener, WeekView.EmptyViewLongPressListener, WeekView.EmptyViewClickListener, WeekView.AddEventClickListener, WeekView.DropListener {



    val TYPE_DAY_VIEW = 1
    val TYPE_THREE_DAY_VIEW = 2
    val TYPE_WEEK_VIEW = 3

    private var mWeekViewType = TYPE_THREE_DAY_VIEW
    private lateinit var shortDateFormat: DateFormat
    private lateinit var timeFormat: DateFormat

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var viewModel: MainViewModel

    private lateinit var binding: MainFragmentBinding
    val locale = Locale.getDefault()



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        binding = DataBindingUtil.inflate(inflater,R.layout.main_fragment,container,false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        shortDateFormat = WeekViewUtil.getWeekdayWithNumericDayAndMonthFormat(requireActivity(), true)
        timeFormat = android.text.format.DateFormat.getTimeFormat(requireActivity()) ?: SimpleDateFormat("HH:mm", Locale.getDefault())


        // draggable_view.setOnLongClickListener(DragTapListener())

        // Get a reference for the week view in the layout.

        // Show a toast message about the touched event.


        binding.weekView.eventClickListener = this

        // The week view has infinite scrolling horizontally. We have to provide the events of a
        // month every time the month changes on the week view.
        binding.weekView.monthChangeListener = this

        // Set long press listener for events.
        binding.weekView.eventLongPressListener = this

        // Set long press listener for empty view
        binding.weekView.emptyViewLongPressListener = this

        // Set EmptyView Click Listener
        binding.weekView.emptyViewClickListener = this

        // Set AddEvent Click Listener
        binding.weekView.addEventClickListener = this

        // Set Drag and Drop Listener
        binding.weekView.dropListener = this

        // Set minDate
        /*Calendar minDate = Calendar.getInstance();
        minDate.set(Calendar.DAY_OF_MONTH, 1);
        minDate.add(Calendar.MONTH, 1);
        mWeekView.setMinDate(minDate);

        // Set maxDate
        Calendar maxDate = Calendar.getInstance();
        maxDate.add(Calendar.MONTH, 1);
        maxDate.set(Calendar.DAY_OF_MONTH, 10);
        mWeekView.setMaxDate(maxDate);

        Calendar calendar = (Calendar) maxDate.clone();
        calendar.add(Calendar.DATE, -2);
        mWeekView.goToDate(calendar);*/

        //mWeekView.setAutoLimitTime(true);
        //mWeekView.setLimitTime(4, 16);

        //mWeekView.setMinTime(10);
        //mWeekView.setMaxTime(20);

        // Set up a date time interpreter to interpret how the date and time will be formatted in
        // the week view. This is optional.
        setupDateTimeInterpreter(false)

        binding.weekView.isShowNowLine = true
        //  binding.weekView.autoLimitTime = true
        binding.weekView.setLimitTime(0, 10)
        binding.weekView.isUsingCheckersStyle = false
        binding.weekView.columnGap = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 1f, resources.displayMetrics).toInt()
        binding.weekView.hourSeparatorHeight = binding.weekView.columnGap
        binding.weekView.isScrollNumberOfVisibleDays = true
        binding.weekView.dropListener = null
        binding.weekView.allDaySideTitleText = getString(R.string.all_day)
        setDayViewType(TYPE_THREE_DAY_VIEW)
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        binding.weekView.goToDate(cal)
        binding.weekView.scrollListener = object : WeekView.ScrollListener {
            val monthFormatter = SimpleDateFormat("MMM", locale)
            val yearFormatter = SimpleDateFormat("yyyy", locale)

            override fun onFirstVisibleDayChanged(newFirstVisibleDay: Calendar, oldFirstVisibleDay: Calendar?) {
                //we show just the month here, so no need to update it every time
                if (oldFirstVisibleDay == null || oldFirstVisibleDay.get(Calendar.MONTH) != newFirstVisibleDay.get(Calendar.MONTH)) {
                    val date = newFirstVisibleDay.time
                    if (cal.get(Calendar.YEAR) == newFirstVisibleDay.get(Calendar.YEAR)) {
                        binding.weekView.sideSubtitleText = "Room types"
                        binding.weekView.sideTitleText = monthFormatter.format(date)
                    } else {
                        binding.weekView.sideTitleText = monthFormatter.format(date)
                        binding.weekView.sideSubtitleText = yearFormatter.format(date)
                    }
                }
            }
        }
        binding.weekView.weekDaySubtitleInterpreter = object : WeekDaySubtitleInterpreter {
            val dateFormatTitle = SimpleDateFormat("d", locale)

            override fun getFormattedWeekDaySubtitle(date: Calendar): String = dateFormatTitle.format(date.time)
        }
        binding.weekView.eventClickListener = object : WeekView.EventClickListener {
            override fun onEventClick(event: WeekViewEvent, eventRect: RectF) {
            }
        }
    }

    private inner class DragTapListener : View.OnLongClickListener {
        override fun onLongClick(v: View): Boolean {
            val data = ClipData.newPlainText("", "")
            val shadowBuilder = View.DragShadowBuilder(v)
            v.startDrag(data, shadowBuilder, v, 0)
            return true
        }
    }


    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.main, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        when (id) {
            R.id.action_today -> {
                binding.weekView.goToToday()
                return true
            }
            R.id.action_day_view -> {
                if (!item.isChecked) {
                    item.isChecked = true
                    setDayViewType(TYPE_DAY_VIEW)
                }
                return true
            }
            R.id.action_three_day_view -> {
                if (!item.isChecked) {
                    item.isChecked = true
                    setDayViewType(TYPE_THREE_DAY_VIEW)
                }
                return true
            }
            R.id.action_week_view -> {
                if (!item.isChecked) {
                    item.isChecked = true
                    setDayViewType(TYPE_WEEK_VIEW)
                }
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    fun setDayViewType(dayViewType: Int) {
        setupDateTimeInterpreter(dayViewType == TYPE_WEEK_VIEW)

        when (dayViewType) {
            TYPE_DAY_VIEW -> {
                mWeekViewType = TYPE_DAY_VIEW
                binding.weekView.numberOfVisibleDays = 1
                // Lets change some dimensions to best fit the view.
                binding.weekView.columnGap = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 8f, resources.displayMetrics).toInt()
                binding.weekView.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 12f, resources.displayMetrics)
                binding.weekView.eventTextSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 12f, resources.displayMetrics)
            }
            TYPE_THREE_DAY_VIEW -> {
                mWeekViewType = TYPE_THREE_DAY_VIEW
                binding.weekView.numberOfVisibleDays = 3
                // Lets change some dimensions to best fit the view.
                binding.weekView.columnGap = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 8f, resources.displayMetrics).toInt()
                binding.weekView.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 12f, resources.displayMetrics)
                binding.weekView.eventTextSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 12f, resources.displayMetrics)
            }
            TYPE_WEEK_VIEW -> {
                mWeekViewType = TYPE_WEEK_VIEW
                binding.weekView.numberOfVisibleDays = 7
                // Lets change some dimensions to best fit the view.
                binding.weekView.columnGap = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 2f, resources.displayMetrics).toInt()
                binding.weekView.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 10f, resources.displayMetrics)
                binding.weekView.eventTextSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 10f, resources.displayMetrics)
            }
        }
    }

    /**
     * Set up a date time interpreter which will show short date values when in week view and long
     * date values otherwise.
     *
     * @param shortDate True if the date values should be short.
     */
    protected open fun setupDateTimeInterpreter(shortDate: Boolean) {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val normalDateFormat = WeekViewUtil.getWeekdayWithNumericDayAndMonthFormat(requireActivity(), false)
        binding.weekView.dateTimeInterpreter = object : DateTimeInterpreter {
            override fun getFormattedTimeOfDay(hour: Int, minutes: Int): String {
                calendar.set(Calendar.HOUR_OF_DAY, hour)
                calendar.set(Calendar.MINUTE, minutes)
                return timeFormat.format(calendar.time)
            }

            override fun getFormattedWeekDayTitle(date: Calendar): String {
                return if (shortDate) shortDateFormat.format(date.time) else normalDateFormat.format(date.time)
            }
        }
    }

    protected fun getEventTitle(startCal: Calendar, endCal: Calendar? = null, allDay: Boolean = false): String {
        val startDate = startCal.time
        val endDate = endCal?.time
        return when {
            allDay -> {
                if (endCal == null || WeekViewUtil.isSameDay(startCal, endCal))
                    shortDateFormat.format(startDate)
                else "${shortDateFormat.format(startDate)}..${shortDateFormat.format(endDate)}"
            }
            endCal == null -> "${shortDateFormat.format(startDate)} ${timeFormat.format(startDate)}"
            WeekViewUtil.isSameDay(startCal, endCal) -> "${shortDateFormat.format(startDate)} ${timeFormat.format(startDate)}..${timeFormat.format(endDate)}"
            else -> "${shortDateFormat.format(startDate)} ${timeFormat.format(startDate)}..${shortDateFormat.format(endDate)} ${timeFormat.format(endDate)}"
        }
    }

    override fun onEventClick(event: WeekViewEvent, eventRect: RectF) {
        Toast.makeText(context, "Clicked " + event.name, Toast.LENGTH_SHORT).show()
    }

    override fun onEventLongPress(event: WeekViewEvent, eventRect: RectF) {
        Toast.makeText(context, "Long pressed event: " + event.name, Toast.LENGTH_SHORT).show()
    }

    override fun onEmptyViewLongPress(time: Calendar) {
        Toast.makeText(context, "Empty view long pressed: " + getEventTitle(time), Toast.LENGTH_SHORT).show()
    }

    override fun onEmptyViewClicked(date: Calendar) {
        Toast.makeText(context, "Empty view" + " clicked: " + getEventTitle(date), Toast.LENGTH_SHORT).show()
    }

    override fun onMonthChange(newYear: Int, newMonth: Int): MutableList<out WeekViewEvent>? {
        // Populate the week view with some events.
        val events = ArrayList<WeekViewEvent>()

        var startTime = Calendar.getInstance()
        startTime.set(Calendar.DAY_OF_MONTH, 3)
        startTime.set(Calendar.HOUR_OF_DAY, 3)
        startTime.set(Calendar.MINUTE, 0)
        startTime.set(Calendar.MONTH, newMonth - 1)
        startTime.set(Calendar.YEAR, newYear)
        var endTime = startTime.clone() as Calendar
        endTime.set(Calendar.DAY_OF_MONTH, 4)
        endTime.add(Calendar.HOUR, 1)
        endTime.set(Calendar.MONTH, newMonth - 1)
        var event = WeekViewEvent("First", getEventTitle(startTime, endTime), startTime, endTime,"2")
        event.color = ResourcesCompat.getColor(resources, R.color.event_color_01, null)
        events.add(event)


        return events
    }

    override fun onAddEventClicked(startTime: Calendar, endTime: Calendar) {
        Toast.makeText(context, "Add event clicked.", Toast.LENGTH_SHORT).show()
    }

    override fun onDrop(view: View, date: Calendar) {
        Toast.makeText(context, "View dropped to " + date.toString(), Toast.LENGTH_SHORT).show()
    }


}
